#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

int test_motorola()
{
}

int main(int argc, char **argv)
{
    printf("motorola testing started\n");
    int result = test_motorola(argc, argv);
    printf("motorola testing ended\n");
    return result;
}
